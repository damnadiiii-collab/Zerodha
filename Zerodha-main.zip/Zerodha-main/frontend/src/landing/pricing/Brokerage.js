import React from 'react';

function Brokerage() {
    return (
        <h1>Brokerage</h1>
    );
}

export default Brokerage;