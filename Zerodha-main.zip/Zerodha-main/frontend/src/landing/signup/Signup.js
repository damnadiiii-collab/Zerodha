import React from 'react';

function Signup() {
    return (
        <h1>Sign Up</h1>
    );
}

export default Signup;